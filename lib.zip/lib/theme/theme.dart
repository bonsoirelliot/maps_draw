import 'package:flutter/cupertino.dart';

class AppTheme {
  static const coral = Color(0xFFFF4242);
  static const gray = Color(0xFF575757);
  static const lightGray = Color(0xFFD9D9D9);
}
