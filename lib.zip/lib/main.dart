import 'package:flutter/material.dart';
import 'package:map_draw/app.dart';

void main() {
  runApp(MapDraw());
}
